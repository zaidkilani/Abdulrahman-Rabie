# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrLeaveType(models.Model):
    _inherit = 'hr.leave.type'

    month_cap = fields.Integer(
        'Month Cap', default=0, help="Monthly cap for this leave type in its type.\n for example:\nif time off in days so limit is days per month.\n if time off in hours so limit is hours per month.\nSet zero to no limit.")
