# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import AccessError, UserError, ValidationError
from datetime import datetime
import calendar
class HolidaysRequest(models.Model):
    _inherit = "hr.leave"

    @api.model_create_multi
    def create(self, vals_list):
        """ Override to apply the month cap """
        for values in vals_list:
            employee_id = values.get('employee_id', False)
            leave_type_id = values.get('holiday_status_id')
            number_of_days = values.get('number_of_days')
            start_date = values.get('date_from', False)
            if employee_id and leave_type_id and number_of_days and start_date:
                start_date = datetime.strptime(start_date, '%Y-%m-%d %H:%M:%S')
                month_cap = self.env['hr.leave.type'].browse(leave_type_id).month_cap
                if month_cap != 0:
                    # TODO more complex logic to check if the leave is in the same month as the cap as if user requst for last day of month and first day of month
                    # Currently it will only check if the leave is in the same month as the cap and employee should separate the leaves
                    
                    # If the employee requesting more than the month cap, raise an error no need to check the number of days already taken for the month
                    if number_of_days > month_cap:
                        raise ValidationError(
                            "You can only apply for %s days per month" % month_cap)
                    # Get the number of days already taken for the month
                    
                    last_day_of_month = calendar.monthrange(start_date.year, start_date.month)[1]
                    start_month = start_date.replace(day=1)
                    end_month = start_date.replace(day=last_day_of_month)
                    taken_holidays = self.search([('employee_id', '=', employee_id),('holiday_status_id', '=', leave_type_id),('state', '!=', 'refuse'),('date_from', '>=', start_month),('date_to', '<=', end_month)])
                    count_of_unit = sum(taken_holidays.mapped('number_of_days'))
                    # If the employee has already taken more than the month cap, raise an error
                    if count_of_unit + number_of_days >= month_cap:
                        raise ValidationError("You can only apply for %s days per month and you already applied for %s days" % (
                            month_cap, count_of_unit))
        holidays = super(HolidaysRequest, self).create(vals_list)
        return holidays
    
    def write(self, values):
        employee_id = values.get('employee_id', self.employee_id)
        leave_type_id = values.get('holiday_status_id', self.holiday_status_id)
        number_of_days = values.get('number_of_days', self.number_of_days)
        start_date = values.get('date_from', self.date_from)
        if employee_id and leave_type_id and number_of_days and start_date:
            
            if not isinstance(employee_id, int):
                employee_id = employee_id.id
            if not isinstance(leave_type_id, int):
                leave_type_id = leave_type_id.id
            if isinstance(start_date, str):
                start_date = datetime.strptime(start_date, '%Y-%m-%d %H:%M:%S')
            month_cap = self.env['hr.leave.type'].browse(leave_type_id).month_cap
            if month_cap != 0:
                # TODO more complex logic to check if the leave is in the same month as the cap as if user requst for last day of month and first day of month
                # Currently it will only check if the leave is in the same month as the cap and employee should separate the leaves
                
                # If the employee requesting more than the month cap, raise an error no need to check the number of days already taken for the month
                if number_of_days > month_cap:
                    raise ValidationError( "You can only apply for %s days per month" % month_cap)
                # Get the number of days already taken for the month
                last_day_of_month = calendar.monthrange(start_date.year, start_date.month)[1]
                start_month = start_date.replace(day=1)
                end_month = start_date.replace(day=last_day_of_month)
                taken_holidays = self.search([('employee_id', '=', employee_id), ('holiday_status_id', '=', leave_type_id), (
                        'state', '!=', 'refuse'), ('date_from', '>=', start_month), ('date_to', '<=', end_month),('id', '!=', self.id)])
                count_of_unit = sum(  taken_holidays.mapped('number_of_days'))
                # If the employee has already taken more than the month cap, raise an error
                if count_of_unit + number_of_days >= month_cap:
                    raise ValidationError("You can only apply for %s days per month and you already applied for %s days" % (month_cap, count_of_unit))
        res = super(HolidaysRequest, self).write(values)
        return res