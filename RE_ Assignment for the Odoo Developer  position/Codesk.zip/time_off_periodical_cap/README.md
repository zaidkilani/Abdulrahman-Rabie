Task 1 for Codesk Solutions

Time Off Periodical Cap

How To Use


1. Go to Time Off defination

2. Define month cap value and read help on field


3. Try to request a new time off



