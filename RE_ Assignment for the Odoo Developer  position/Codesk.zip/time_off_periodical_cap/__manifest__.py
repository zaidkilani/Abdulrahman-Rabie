# -*- coding: utf-8 -*-
{
    'name': "Time Off Periodical Cap",

    'summary': """
        Time Off Periodical Cap""",

    'description': """
        Time Off Periodical Cap
    """,

    'author': "Abdulrahman Rabie",


    'category': 'Human Resources',
    'version': '15.0.1',


    'depends': ['base','hr_holidays'],


    'data': [

        'views/hr_leave_type.xml',
    ],

}
