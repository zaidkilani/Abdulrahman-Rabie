# -*- coding: utf-8 -*-
{
    'name': "Currency Rate Extended",

    'summary': """
        Currency Rate Extended""",

    'description': """
        Currency Rate Extended
    """,

    'author': "Abdulrahman Rabie",



    'category': 'Accounting',
    'version': '15.0.1',

    'depends': ['base','product','account'],


    'data': [

        'views/res_currency.xml',

    ],

}
