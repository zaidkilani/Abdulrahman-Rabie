Task 2 for Codesk Solutions

Currency Rate Extended

How To Use


1. Go to Currency will find new field "Is Foreign Currency"

2. If Field Is Foreign Currency is true you will see all new fields in the table of currency rates




