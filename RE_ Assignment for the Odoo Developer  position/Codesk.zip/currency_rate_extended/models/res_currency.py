# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import AccessError, UserError, ValidationError


class ResCurrency(models.Model):
    _inherit = "res.currency"
    is_foreign_currency = fields.Boolean(string="Is Foreign Currency", default=False)
class ResCurrencyRate(models.Model):
    _inherit = "res.currency.rate"
    
    secondary_sale_price = fields.Monetary(
        string="Secondary Sale Price", currency_field='currency_id')
    secondary_purchase_price = fields.Monetary('Secondary Purchase Price', currency_field='currency_id')
    base_sale_price = fields.Monetary('Base Sale Price', currency_field='currency_id')
    base_purchase_price = fields.Monetary('Base Purchase Price', currency_field='currency_id')
    tolerance = fields.Integer(string="Tolerance")
    evaluation = fields.Monetary(string="Evaluation", currency_field='currency_id')
