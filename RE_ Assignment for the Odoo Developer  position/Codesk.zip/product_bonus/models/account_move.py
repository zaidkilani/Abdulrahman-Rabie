# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import AccessError, UserError, ValidationError

class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    is_bonus_line = fields.Boolean(string="Bonus Line", default=False)
    bonus_qty = fields.Float(string="Bonus Quantity", compute="_compute_bonus_qty", store=True)
    
    @api.depends('quantity','product_id')
    def _compute_bonus_qty(self):
        for line in self:
            if line.product_id.has_bonus or line.product_id.categ_id.has_bonus:
                line_qty = line.product_id.bonus_ordered_qty or line.product_id.categ_id.bonus_ordered_qty
                line_bonus = line.product_id.bonus_qty or line.product_id.categ_id.bonus_qty
                if line.quantity >= line_qty and line_qty >0:
                    line.bonus_qty = int(line.quantity / line_qty) * line_bonus
                else:
                    line.bonus_qty = 0
class AccountMove(models.Model):
    _inherit = "account.move"


    def _remove_existing_bonus_lines(self):
        self.ensure_one()
        self.line_ids.filtered(lambda x: x.is_bonus_line).unlink()
        
    def _create_bonus_lines(self):
        # out_invoices only
        for inv in self.filtered(lambda x: x.move_type == 'out_invoice'):
            inv._remove_existing_bonus_lines()
            for line in inv.invoice_line_ids:
                if line.product_id.has_bonus or line.product_id.categ_id.has_bonus:
                    line_qty = line.product_id.bonus_ordered_qty or line.product_id.categ_id.bonus_ordered_qty
                    line_bonus = line.product_id.bonus_qty or line.product_id.categ_id.bonus_qty
                    if line.quantity >= line_qty and line_qty >0:
                        bomus_line = line.copy({
                            'is_bonus_line': True,
                            'exclude_from_invoice_tab': True,
                            'price_unit': 0.0,
                            'quantity': int(line.quantity / line_qty) * line_bonus,
                            'balance':0.0,
                            'credit': 0.0,
                            'debit': 0.0,
                        })
                        
    
    @api.model_create_multi
    def create(self, vals_list):
        move = super(AccountMove, self).create(vals_list)
        move._create_bonus_lines()
        return move

    def write(self, vals):
        res = super(AccountMove, self).write(vals)
        self._create_bonus_lines()
        return res