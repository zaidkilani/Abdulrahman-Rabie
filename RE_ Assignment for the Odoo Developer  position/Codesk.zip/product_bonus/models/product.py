# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ProductCategory(models.Model):
    _inherit = 'product.category'
    
    has_bonus = fields.Boolean(string="Has Bonus Rules", default=False)
    bonus_ordered_qty = fields.Float(string="Ordered Quantity", default=0.0)
    bonus_qty = fields.Float(string="Bonus Quantity", default=0.0)
    
    
class ProductTemplate(models.Model):
    _inherit = 'product.template'
    
    has_bonus = fields.Boolean(string="Has Bonus Rules", default=False)
    bonus_ordered_qty = fields.Float(string="Ordered Quantity", default=0.0)
    bonus_qty = fields.Float(string="Bonus Quantity", default=0.0)
    
class ProductProduct(models.Model):
    _inherit = 'product.product'
    
    has_bonus = fields.Boolean(
        string="Has Bonus Rules", related='product_tmpl_id.has_bonus')
    bonus_ordered_qty = fields.Float(string="Ordered Quantity", related= 'product_tmpl_id.bonus_ordered_qty')
    bonus_qty = fields.Float(string="Bonus Quantity", related= 'product_tmpl_id.bonus_qty')

