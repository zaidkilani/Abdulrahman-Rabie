# -*- coding: utf-8 -*-

from . import product
from . import account_move
