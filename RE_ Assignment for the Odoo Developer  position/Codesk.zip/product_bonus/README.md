Task 3 for Codesk Solutions

Product Bonus

How To Use


1. Go to Category or Product and will find new field "Has Bonus"

2. If field is true will see new two fields as viedo

3. After Create/Modify an invoice will find the bonus line in the tab 'Journal Items'  not in 'Invoice Lines' as it is hidden as per task description
    with new two hidden field you can use "three points" to show them 1.Is bonus line 2.Quantity




