from odoo import api, SUPERUSER_ID


